﻿/* global app */'use strict';app.widgetConfig = {
demoMain :  { id:'demoMain',  type:PageWidget,  widgets:[]},                                                                                                 
};
