/* global app */'use strict';app.eventMap = {
};
